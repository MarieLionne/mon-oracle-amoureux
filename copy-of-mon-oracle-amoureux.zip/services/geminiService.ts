
import { GoogleGenAI, Type } from "@google/genai";
import { OracleCard, Reading } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getOracleReading(card: OracleCard, userQuestion: string = ""): Promise<Reading> {
  const model = 'gemini-3-flash-preview';
  
  const systemInstruction = `
    Tu es le "Grand Oracle de l'Éveil Amoureux". Ton ton est poétique, mystique, bienveillant, et profondément réconfortant.
    Tu interprètes une carte tirée d'un oracle de 88 cartes pour un utilisateur qui cherche des réponses sur sa vie amoureuse.
    Ta mission est de guider, de soigner les cœurs et d'offrir une vision spirituelle des énergies.
    Même pour les cartes d' "Ombre", reste constructif et propose un chemin de guérison.
    Réponds TOUJOURS en JSON selon le format demandé.
  `;

  const prompt = `
    L'utilisateur a tiré la carte suivante : "${card.name}" (Catégorie: ${card.category}).
    Description courte : ${card.description}
    Question de l'utilisateur : ${userQuestion || "Quelle est l'énergie de mon cœur aujourd'hui ?"}
    
    Fournis une lecture approfondie incluant :
    1. Une interprétation poétique du message de la carte (3-4 phrases).
    2. Un conseil pratique et spirituel pour avancer.
    3. Un ressenti sur "l'énergie" actuelle (ex: Fluide, Stagnante, En feu, Douce...).
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            interpretation: { type: Type.STRING },
            advice: { type: Type.STRING },
            energy: { type: Type.STRING },
          },
          required: ["interpretation", "advice", "energy"],
        }
      }
    });

    const result = JSON.parse(response.text);
    
    return {
      card: card,
      interpretation: result.interpretation,
      advice: result.advice,
      energy: result.energy,
      timestamp: new Date(),
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      card: card,
      interpretation: "L'univers murmure une vérité que les mots peinent à saisir. Prenez un instant pour écouter le silence de votre cœur.",
      advice: "Faites confiance à votre intuition première.",
      energy: "Mystérieuse",
      timestamp: new Date(),
    };
  }
}
