
import React, { useState, useEffect } from 'react';
import { Sparkles, History, LayoutGrid, ArrowLeft, Heart, Share2, ShoppingBag, Star, Check, Zap } from 'lucide-react';
import { ORACLE_CARDS, PRICING_PLANS, SHOP_ITEMS as DEFAULT_SHOP_ITEMS } from './constants';
import { OracleCard, Reading, AppState, ShopItem } from './types';
import { getOracleReading } from './services/geminiService';
import OracleCardUI from './components/OracleCardUI';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.LANDING);
  const [history, setHistory] = useState<Reading[]>([]);
  const [currentReading, setCurrentReading] = useState<Reading | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [userQuestion, setUserQuestion] = useState("");
  const [isFlipped, setIsFlipped] = useState(false);
  
  const [shopItems, setShopItems] = useState<ShopItem[]>(() => {
    const saved = localStorage.getItem('oracle_shop_items');
    return saved ? JSON.parse(saved) : DEFAULT_SHOP_ITEMS;
  });

  const drawCard = async (card: OracleCard) => {
    setIsLoading(true);
    setAppState(AppState.READING);
    setIsFlipped(false);
    
    const reading = await getOracleReading(card, userQuestion);
    
    setCurrentReading(reading);
    setHistory(prev => [reading, ...prev]);
    setIsLoading(false);
    
    setTimeout(() => {
      setIsFlipped(true);
    }, 1000);
  };

  const handleRandomDraw = () => {
    const randomCard = ORACLE_CARDS[Math.floor(Math.random() * ORACLE_CARDS.length)];
    drawCard(randomCard);
  };

  const reset = () => {
    setAppState(AppState.LANDING);
    setCurrentReading(null);
    setIsFlipped(false);
    setUserQuestion("");
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex flex-col text-white selection:bg-fuchsia-500/40 bg-[#050206]">
      {/* Fond Dynamique */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[80%] h-[80%] bg-fuchsia-900/20 blur-[180px] rounded-full animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[80%] h-[80%] bg-cyan-900/15 blur-[180px] rounded-full animate-pulse" style={{ animationDelay: '3s' }}></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-40"></div>
      </div>

      {/* Navigation */}
      <nav className="relative z-50 px-10 py-8 flex justify-between items-center bg-black/60 backdrop-blur-3xl border-b border-white/5 shadow-2xl">
        <div className="flex items-center gap-6 cursor-pointer group" onClick={reset}>
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-fuchsia-600 via-rose-500 to-amber-500 flex items-center justify-center shadow-[0_0_50px_rgba(255,0,127,0.6)] group-hover:rotate-12 transition-all duration-700">
            <Heart className="w-10 h-10 text-white fill-current animate-pulse" />
          </div>
          <div className="flex flex-col">
            <h1 className="font-decorative text-4xl md:text-5xl tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-white to-rose-200 leading-none">
              Mon Oracle Amoureux
            </h1>
            <span className="text-[11px] uppercase tracking-[0.7em] text-fuchsia-400 font-black mt-3">Guidance Éternelle</span>
          </div>
        </div>
        
        <div className="flex items-center gap-6 md:gap-12">
          <button onClick={() => setAppState(AppState.SHOP)} className="hidden sm:flex items-center gap-3 text-white/50 hover:text-fuchsia-300 px-4 py-2 transition-all text-xs font-decorative uppercase tracking-[0.4em]">
            <ShoppingBag className="w-6 h-6" />
            <span>Boutique</span>
          </button>
          <button onClick={() => setAppState(AppState.PRICING)} className="flex items-center gap-3 text-amber-400 hover:text-amber-200 px-4 py-2 transition-all text-xs font-decorative uppercase tracking-[0.4em]">
            <Star className="w-6 h-6 fill-current animate-pulse shadow-amber-500" />
            <span className="hidden md:inline">Premium</span>
          </button>
          <div className="w-[1px] h-12 bg-white/10 mx-2"></div>
          <button onClick={() => setAppState(AppState.HISTORY)} className="p-4 bg-white/5 rounded-full text-white/60 hover:text-white transition-all hover:bg-white/15 hover:scale-110 shadow-lg">
            <History className="w-7 h-7" />
          </button>
        </div>
      </nav>

      <main className="relative z-10 flex-1 flex flex-col container mx-auto px-8 py-12">
        
        {appState === AppState.LANDING && (
          <div className="flex-1 flex flex-col items-center justify-center max-w-7xl mx-auto text-center space-y-20 py-12 animate-in fade-in slide-in-from-bottom-16 duration-1000">
            
            {/* Le Cœur de Guidance */}
            <div className="group relative">
               <div className="absolute -inset-6 bg-gradient-to-r from-fuchsia-600 via-rose-500 to-amber-500 rounded-full blur-2xl opacity-40 group-hover:opacity-80 transition duration-1000"></div>
               <div className="relative px-12 py-5 bg-black/80 border border-white/30 rounded-full flex items-center gap-6 backdrop-blur-3xl shadow-2xl">
                  <div className="w-4 h-4 bg-fuchsia-500 rounded-full animate-ping shadow-[0_0_25px_rgba(255,0,255,1)]"></div>
                  <span className="text-sm font-decorative uppercase tracking-[0.5em] text-fuchsia-100 font-bold">L'énergie du moment : L'Amour Pur</span>
                  <Heart className="w-7 h-7 text-rose-500 fill-current animate-pulse pulse-heart" />
               </div>
            </div>

            <div className="space-y-12">
              <h2 className="font-decorative text-8xl md:text-[12rem] font-black leading-none drop-shadow-[0_25px_70px_rgba(0,0,0,1)]">
                Votre destin <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-400 via-amber-300 to-cyan-400">s'illumine</span>
              </h2>
              <p className="font-serif text-4xl md:text-6xl text-white/90 leading-relaxed italic max-w-5xl mx-auto font-light px-8">
                "Une question, une carte, un avenir. Laissez les 88 secrets de l'oracle vous guider avec bienveillance."
              </p>
            </div>

            <div className="w-full max-w-5xl space-y-16">
              <div className="relative group">
                <input 
                  type="text" 
                  value={userQuestion}
                  onChange={(e) => setUserQuestion(e.target.value)}
                  placeholder="Posez votre question à l'Oracle..."
                  className="w-full bg-white/5 border-2 border-white/15 rounded-[50px] px-16 py-12 text-3xl md:text-5xl outline-none focus:border-fuchsia-500/60 focus:bg-white/10 transition-all placeholder:text-white/10 backdrop-blur-3xl text-center shadow-[0_40px_120px_rgba(0,0,0,0.6)]"
                />
                <div className="absolute right-14 top-1/2 -translate-y-1/2">
                   <Sparkles className="w-14 h-14 text-amber-300 animate-pulse drop-shadow-[0_0_30px_rgba(253,224,71,0.9)]" />
                </div>
              </div>

              {/* Les deux boutons d'action vibrants */}
              <div className="flex flex-col sm:flex-row justify-center items-center gap-12">
                <button 
                  onClick={handleRandomDraw} 
                  disabled={isLoading} 
                  className="group relative px-24 py-12 bg-white text-black font-decorative font-black text-3xl rounded-full overflow-hidden hover:scale-110 transition-all shadow-[0_30px_100px_rgba(255,255,255,0.2)] active:scale-95"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-amber-200 via-white to-fuchsia-300 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  <span className="relative z-10 flex items-center justify-center gap-6">
                    {isLoading ? 'Consultation...' : 'Tirage du Destin'}
                    <Zap className="w-8 h-8 fill-current text-fuchsia-600" />
                  </span>
                </button>
                
                <button 
                  onClick={handleRandomDraw} 
                  className="px-20 py-12 bg-fuchsia-600/15 border-2 border-fuchsia-500/40 text-fuchsia-300 font-decorative font-bold text-2xl rounded-full hover:bg-fuchsia-500/25 hover:text-white transition-all backdrop-blur-3xl flex items-center justify-center gap-6 group shadow-2xl"
                >
                   Message Express
                   <ArrowLeft className="w-7 h-7 rotate-180 group-hover:translate-x-5 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* READING STATE */}
        {appState === AppState.READING && currentReading && (
          <div className="max-w-7xl mx-auto w-full flex flex-col lg:flex-row items-center lg:items-start gap-28 py-16 animate-in fade-in zoom-in duration-1000">
            <div className="w-full max-w-md md:max-w-2xl shrink-0 animate-float">
              <OracleCardUI card={currentReading.card} isFlipped={isFlipped} />
              {isFlipped && (
                <button onClick={() => {}} className="mt-16 w-full flex items-center justify-center gap-6 px-14 py-10 rounded-full bg-white/5 border border-white/20 text-white font-decorative text-base uppercase tracking-[0.5em] hover:bg-white/10 transition-all shadow-2xl hover:scale-105">
                  <Share2 className="w-8 h-8 text-fuchsia-400" /> Partager ma Guidance
                </button>
              )}
            </div>
            
            <div className="flex-1 space-y-16 pt-10">
              <div className="space-y-10 text-center lg:text-left">
                <div className="flex items-center justify-center lg:justify-start gap-8 mb-6">
                   <div className="h-[3px] w-24 bg-fuchsia-500 shadow-[0_0_15px_fuchsia]"></div>
                   <span className="text-fuchsia-400 font-decorative text-xl tracking-[0.7em] uppercase font-black">Révélation Sacrée</span>
                </div>
                <h2 className="font-decorative text-7xl md:text-[9rem] text-white uppercase drop-shadow-[0_20px_50px_rgba(0,0,0,0.8)] leading-none">{currentReading.card.name}</h2>
                <div className="inline-flex items-center gap-8 px-12 py-6 rounded-full bg-fuchsia-500/20 border-2 border-fuchsia-500/30 text-lg font-decorative shadow-inner">
                   Vibration : 
                   <span className="text-white font-black uppercase tracking-[0.2em]">{currentReading.energy}</span>
                </div>
              </div>
              
              <div className="space-y-14">
                <section className="space-y-10">
                  <p className="font-serif text-4xl md:text-6xl text-white/95 leading-snug italic drop-shadow-2xl">
                    "{currentReading.interpretation}"
                  </p>
                </section>
                
                <div className="p-1.5 w-full bg-gradient-to-r from-fuchsia-500 via-amber-400 to-cyan-500 rounded-[70px] shadow-[0_40px_100px_rgba(0,0,0,0.6)]">
                  <section className="p-16 rounded-[68px] bg-black/95 backdrop-blur-3xl space-y-10">
                    <h4 className="font-decorative text-amber-400 text-lg uppercase tracking-[0.6em] flex items-center gap-5">
                      <Zap className="w-8 h-8 fill-current" /> Le Conseil du Cœur
                    </h4>
                    <p className="text-3xl md:text-4xl text-white/95 leading-relaxed font-light font-serif italic">
                      {currentReading.advice}
                    </p>
                  </section>
                </div>
              </div>

              <div className="flex flex-wrap justify-center lg:justify-start gap-12 pt-16">
                <button onClick={reset} className="px-24 py-12 rounded-full bg-white text-black font-black font-decorative text-2xl uppercase tracking-[0.2em] hover:scale-110 transition-all shadow-[0_0_60px_rgba(255,255,255,0.3)]">
                  Nouveau Tirage
                </button>
              </div>
            </div>
          </div>
        )}

        {/* SHOP STATE */}
        {appState === AppState.SHOP && (
          <div className="max-w-7xl mx-auto w-full space-y-20 py-16 animate-in fade-in slide-in-from-bottom-12 duration-1000">
            <div className="text-center space-y-6">
              <h2 className="font-decorative text-7xl md:text-9xl text-white">Boutique Mystique</h2>
              <p className="font-serif italic text-3xl text-white/60">Objets sacrés pour vos rituels d'amour</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
              {shopItems.map((item) => (
                <div key={item.id} className="group bg-white/5 border border-white/10 rounded-[40px] overflow-hidden hover:bg-white/10 transition-all shadow-2xl">
                  <div className="aspect-[4/5] overflow-hidden">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                  </div>
                  <div className="p-10 space-y-6">
                    <div className="flex justify-between items-start">
                      <span className="text-fuchsia-400 font-decorative text-xs uppercase tracking-widest">{item.category}</span>
                      <span className="text-2xl font-black text-white">{item.price}</span>
                    </div>
                    <h3 className="text-3xl font-serif italic text-white">{item.name}</h3>
                    <button className="w-full py-5 bg-white/10 hover:bg-white hover:text-black rounded-full transition-all text-sm font-black font-decorative uppercase tracking-widest">
                      Découvrir
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-center pt-10">
              <button onClick={reset} className="px-14 py-6 border-2 border-white/20 rounded-full text-white font-decorative uppercase tracking-[0.5em] hover:bg-white/5 transition-all">Retour à l'Oracle</button>
            </div>
          </div>
        )}

        {/* PRICING STATE */}
        {appState === AppState.PRICING && (
          <div className="max-w-7xl mx-auto w-full space-y-20 py-16 animate-in fade-in slide-in-from-bottom-12 duration-1000">
             <div className="text-center space-y-6">
              <h2 className="font-decorative text-7xl md:text-9xl text-white">Élevez votre Âme</h2>
              <p className="font-serif italic text-3xl text-white/60">Choisissez l'intensité de votre guidance</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              {PRICING_PLANS.map((plan) => (
                <div key={plan.id} className={`relative p-14 rounded-[50px] border-2 ${plan.isPopular ? 'bg-white/10 border-fuchsia-500 shadow-[0_0_80px_rgba(255,0,127,0.3)]' : 'bg-white/5 border-white/10'} space-y-12 transition-all hover:scale-105`}>
                  {plan.isPopular && (
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 px-8 py-3 bg-fuchsia-600 rounded-full text-[10px] font-black uppercase tracking-[0.5em]">Plus Choisi</div>
                  )}
                  <div className="space-y-4">
                    <h3 className="font-decorative text-3xl text-white">{plan.name}</h3>
                    <div className="text-6xl font-black text-white">{plan.price}</div>
                    <p className="font-serif italic text-xl text-white/60">{plan.description}</p>
                  </div>
                  <ul className="space-y-6">
                    {plan.features.map((f, i) => (
                      <li key={i} className="flex items-center gap-4 text-white/80">
                        <Check className="w-6 h-6 text-fuchsia-500" />
                        <span className="text-lg">{f}</span>
                      </li>
                    ))}
                  </ul>
                  <button className={`w-full py-8 rounded-full font-black font-decorative text-sm uppercase tracking-widest transition-all ${plan.isPopular ? 'bg-fuchsia-600 text-white shadow-3xl' : 'bg-white text-black'}`}>
                    {plan.buttonText}
                  </button>
                </div>
              ))}
            </div>
            <div className="flex justify-center pt-10">
              <button onClick={reset} className="px-14 py-6 border-2 border-white/20 rounded-full text-white font-decorative uppercase tracking-[0.5em] hover:bg-white/5 transition-all">Retour à l'Oracle</button>
            </div>
          </div>
        )}

        {/* HISTORY STATE */}
        {appState === AppState.HISTORY && (
          <div className="max-w-6xl mx-auto w-full space-y-16 py-16 animate-in fade-in slide-in-from-bottom-12 duration-1000">
             <div className="text-center space-y-6">
              <h2 className="font-decorative text-7xl md:text-9xl text-white">Vos Mémoires</h2>
              <p className="font-serif italic text-3xl text-white/60">Le fil conducteur de votre destin amoureux</p>
            </div>
            
            {history.length === 0 ? (
              <div className="text-center py-24 bg-white/5 rounded-[50px] border border-dashed border-white/20">
                <p className="font-serif italic text-3xl text-white/30">L'histoire reste à s'écrire... Faites votre premier tirage.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                {history.map((reading, i) => (
                  <div key={i} className="p-10 bg-white/5 border border-white/10 rounded-[40px] hover:bg-white/10 transition-all group flex gap-8 items-center">
                    <div className="w-28 h-40 shrink-0">
                       <OracleCardUI card={reading.card} isFlipped={true} />
                    </div>
                    <div className="space-y-4">
                       <span className="text-fuchsia-400 font-decorative text-[10px] uppercase tracking-widest">{new Date(reading.timestamp).toLocaleDateString()}</span>
                       <h3 className="text-3xl font-decorative text-white uppercase">{reading.card.name}</h3>
                       <p className="text-lg text-white/60 font-serif italic line-clamp-2">"{reading.interpretation}"</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div className="flex justify-center pt-10">
              <button onClick={reset} className="px-14 py-6 border-2 border-white/20 rounded-full text-white font-decorative uppercase tracking-[0.5em] hover:bg-white/5 transition-all">Retour à l'Oracle</button>
            </div>
          </div>
        )}

      </main>

      <footer className="relative z-10 px-10 py-12 flex flex-col md:flex-row justify-between items-center gap-10 bg-black/60 border-t border-white/5 text-white/40 text-xs font-decorative uppercase tracking-[0.4em] backdrop-blur-3xl">
        <p>© 2025 Mon Oracle Amoureux - Énergie Divine & IA</p>
        <div className="flex gap-10">
          <a href="#" className="hover:text-fuchsia-400 transition-colors">Politique de Confidentialité</a>
          <a href="#" className="hover:text-fuchsia-400 transition-colors">Mentions Légales</a>
          <a href="#" className="hover:text-fuchsia-400 transition-colors">Contact</a>
        </div>
      </footer>
    </div>
  );
};

export default App;
